package novy;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;


public class Produ {
    public static void main(String[] args) throws RemoteException, NotBoundException, MalformedURLException, InterruptedException {
        Car ms = new Car(5, "asd");
        Prod_Con_Methods vzdalenyPC = (Prod_Con_Methods) Naming.lookup("rmi://134.103.212.238/A4");
        vzdalenyPC.produce(ms);
        System.out.println(ms.toString() + " current size of Server: " + vzdalenyPC.size());

    }
}
